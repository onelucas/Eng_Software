public class ImprimeSoma {

	public static void main(String[] args) {
		int soma = 0;
		for (int i = 0; i < 1000; i += 3) {
			soma += i;
			System.out.println(soma);
		}
	}
	
}
