package aula4;

public class Cliente {

	String nome;
	String cpf;
	String telefone;
	String email;
}
