package aula4;

public class Conta {

	int numero;
	Cliente titular;
	double saldo;
	
	void deposita(double valor) {
		this.saldo = this.saldo + valor;
	}
	
	boolean saca(double valor) {
		if(this.saldo >= valor) {
			this.saldo = this.saldo - valor;
			return true;
		}
		return false;
	}
	
	boolean transfere(Conta conta, double valor) {
		boolean sacou = saca(valor);
		if(sacou) {
			conta.deposita(valor);
		}
		return sacou;
	}
	
}
