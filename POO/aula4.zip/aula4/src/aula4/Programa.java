package aula4;

public class Programa {
	
	public static void main(String[] args) {
		
		Cliente cli1 = new Cliente();
		cli1.nome = "Leonardo";
		Cliente cli2 = new Cliente();
		cli2.nome = "Maria";
		
		Conta c1 = new Conta();
		c1.numero = 1;
		c1.titular = cli1;
		c1.saldo = 1500;
		
		Conta c2 = new Conta();
		c2.numero = 1;
		c2.titular = cli2;
		c2.saldo = 1500;
		
		c2.transfere(c1, 50);
		
		c1.deposita(500);
		if(c1.saca(1000)) {
			System.out.println("Saque com sucesso! saldo atual: " + c1.saldo);	
		}else {
			System.out.println("Saldo insuficiente!");
		}
	}

}
