package br.org.catolicasc.exercicio5;

public class FabricaDeCarro {
	
	private static FabricaDeCarro fabrica =  new FabricaDeCarro();
	
	private FabricaDeCarro() {}

	public static FabricaDeCarro getInstance() {
		return fabrica;
	}
}
