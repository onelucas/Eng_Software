package br.org.catolicasc.exercicio5;

public class TestaFabrica {
	
	public static void main(String[] args) {

		FabricaDeCarro fabrica1 = FabricaDeCarro.getInstance();

		FabricaDeCarro fabrica2 = FabricaDeCarro.getInstance();
		
		System.out.println(fabrica1 == fabrica2);
	}

}
