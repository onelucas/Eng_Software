package br.org.catolicasc.exercicio5;

public class Funcionario {
	
	private static int sequenciaIdentifica;
	private int identificador;
	private String nome;
	private String departamento;
	private double salario;
	private String dataEntrada;
	private String rg;
	private boolean estaNaEmpresa;
	
	public Funcionario() {
		Funcionario.sequenciaIdentifica = sequenciaIdentifica +1;
		this.identificador = sequenciaIdentifica;
	}
	
	public Funcionario(String nome) {
		this();
		this.nome = nome;
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getDepartamento() {
		return departamento;
	}
	public void setDepartamento(String departamento) {
		this.departamento = departamento;
	}
	public double getSalario() {
		return salario;
	}
	public void setSalario(double salario) {
		this.salario = salario;
	}
	public String getDataEntrada() {
		return dataEntrada;
	}
	public void setDataEntrada(String dataEntrada) {
		this.dataEntrada = dataEntrada;
	}
	public String getRg() {
		return rg;
	}
	public void setRg(String rg) {
		this.rg = rg;
	}
	public boolean isEstaNaEmpresa() {
		return estaNaEmpresa;
	}
	public void setEstaNaEmpresa(boolean estaNaEmpresa) {
		this.estaNaEmpresa = estaNaEmpresa;
	}

	public int getIdentificador() {
		return identificador;
	}
	
	public void demite() {
		this.estaNaEmpresa = false;
	}
	
}
