package br.org.catolicasc.banco;

public class Cliente {

	String nome;
	String cpf;
	String telefone;
	String email;
}
