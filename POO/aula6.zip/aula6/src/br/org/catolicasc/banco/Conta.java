package br.org.catolicasc.banco;

public class Conta extends Object {

	private static int totalDeContas;

	private int numero;
	private Cliente titular;
	private double saldo;
	private double limite = 100;
	
	Conta(){
		totalDeContas = totalDeContas + 1;
	}
	Conta(Cliente titular){
		this();
		this.titular = titular;
	}
	
	Conta(Cliente titular, int numero){
		this(titular);
		this.numero = numero;
	}
	
	public void deposita(double valor) {
		if(valor < 0) {
			System.out.println(" Valor negativo ");
		} else {
			this.saldo = this.saldo + valor;
		}
	}
	
	boolean saca(double valor) {
		if((this.saldo + limite) >= valor) {
			this.saldo = this.saldo - valor;
			return true;
		}
		return false;
	}
	
	boolean transfere(Conta conta, double valor) {
		boolean sacou = saca(valor);
		if(sacou) {
			conta.deposita(valor);
		}
		return sacou;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
		this.numero = numero;
	}

	public Cliente getTitular() {
		return titular;
	}

	public void setTitular(Cliente titular) {
		this.titular = titular;
	}

	public double getSaldo() {
		return saldo + limite;
	}

	public static int getTotalDeContas() {
		return totalDeContas;
	}
}
