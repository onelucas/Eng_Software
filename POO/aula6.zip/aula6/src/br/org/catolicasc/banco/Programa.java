package br.org.catolicasc.banco;

import java.util.Iterator;

public class Programa {

	public static void main(String[] args) {

		Cliente cli1 = new Cliente();
		cli1.nome = "Leonardo";
		Cliente cli2 = new Cliente();
		cli2.nome = "Maria";

		Conta c1 = new Conta(cli1);
		c1.setNumero(1);
		c1.deposita(1500);

		Conta c2 = new Conta();
		c2.setNumero(1);
		c2.setTitular(cli2);
		c2.deposita(1000);

		Conta[] contas = new Conta[10];
		contas[0] = c1;
		contas[1] = c2;
		contas[2] = new Conta();
		for (Conta conta : contas) {
			if (conta != null) {
				System.out.println("O saldo da conta é: " + conta.getSaldo());
			} else {
				System.out.println("Posição vazia!");
			}
		}
		System.out.println("For percorrendo con índice:");
		for (int i = 0; i < contas.length; i++) {
			Conta c = contas[i];
			if (c != null)
				System.out.println(c.getSaldo());
		}

	}

}
