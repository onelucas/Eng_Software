package aula1;

import javax.swing.JOptionPane;

public class TestaJanelas {
	
	public static void main(String[] args) {
	
		
		int resultado = JOptionPane.showConfirmDialog(null, 
					"Você gosta de java?", 
					"Iforme", 0, 0);
		
		JOptionPane.showMessageDialog(null, 
				"Resultado = " + resultado, 
				"Título",
				2);
		
		Object melhorTime = JOptionPane.showInputDialog(null,
				"Qual o melhor time do Brasil",
				"Escolha",
				3, null, null, "Flamengo!");
		
		JOptionPane.showMessageDialog(null, 
				"Melhor time = " + melhorTime, 
				"Título",
				2);
		
		
	}
}
