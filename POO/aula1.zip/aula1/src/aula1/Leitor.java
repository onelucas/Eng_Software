package aula1;

import java.util.Scanner;

public class Leitor {

	public static void main(String[] args) {
		
		Scanner leitor = new Scanner(System.in);
		System.out.print("Informe seu nome:");
		String nome = leitor.nextLine();
		System.out.println("Seja bem-vindo "+ nome);
		
	}

}
