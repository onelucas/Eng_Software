package aula2;

public class BancoTrimestral {

	public static void main(String[] args) {
		double gastoJaneiro = 15000;
		double gastoFevereiro = 23000;
		double gastoMarco = 17000;
		double gastoTrimestre = gastoJaneiro + gastoFevereiro + gastoMarco;
		double mediaMensal = gastoTrimestre / 3;
		System.out.printf("Gastos do trimestre formatado: %.2f%n", gastoTrimestre); 
		System.out.println("Gastos do trimestre: "+ gastoTrimestre);
		System.out.println("Média mensal do primeiro trimestre = " + mediaMensal);
	}
}
