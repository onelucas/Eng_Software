package aula2;

import java.util.Scanner;

public class LataOleo {

	public static void main(String[] args) {
		double v, r, a;
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Informe o raio  da lata: ");
		r = scanner.nextDouble();
		System.out.print("Informe a altura da lata: ");
		a = scanner.nextDouble();
		v = 3.14159 * r * r * a;
		System.out.println("O volume da lata de óleo é de " + v + " m3");
	}
}
