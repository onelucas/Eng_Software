package aula2;

public class TestaIdade {
	
	
	public static void main(String[] args) {
		
		int idade = 20;
		System.out.println(idade);
		
		double x = 5 * 10;
		System.out.println(x);
		
		boolean maiorIdade = idade >= 18;
		System.out.println(maiorIdade);
		
		int i = 5;
		int j = i;
		i = i + 1;
		
		x = 5.9;
		int z = (int) x;
		System.out.println(z);
		double a = i;
		
	}

}
