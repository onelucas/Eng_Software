package aula2;

import java.util.Scanner;

public class TrocaValores {

	public static void main(String[] args) {
		String nome1 = " é o mestre do universo ";
		String nome2;
		String aux;
		Scanner lerTeclado = new Scanner(System.in);
		System.out.println("Troca valores entre variaveis");
		System.out.print("Qual o seu nome?: ");
		nome2 = lerTeclado.nextLine();
		aux = nome2;
		nome2 = nome1;
		nome1 = aux;
		System.out.println(nome1 + nome2);
	}
}
