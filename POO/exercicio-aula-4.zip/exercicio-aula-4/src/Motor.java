
public class Motor {

	double potencia;
	double velocidadeMaxima;
	
	boolean validaAceleracao(double velocidade) {
		return  velocidade <= this.velocidadeMaxima;
	}
}
