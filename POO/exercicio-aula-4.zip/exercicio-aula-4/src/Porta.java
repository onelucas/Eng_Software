public class Porta {
	boolean open;
	String color;
	double dimX;
	double dimY;
	
	public void abre() {
		this.open = true;
		System.out.println("A porta foi aberta");
	}
	
	public void fecha() {
		this.open = false;
		System.out.println("A porta foi fechada");
	}
	
	public void pinta(String s) {
		this.color = s;
		System.out.println("A cor da porta é " + this.color);

	}
	
	public boolean estaAberta() {
		System.out.println((this.open) ? "A porta esta aberta" : "A porta esta fechada.");
		return this.open;
	}
}
