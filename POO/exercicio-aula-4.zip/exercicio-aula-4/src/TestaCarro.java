
public class TestaCarro {

	public static void main(String[] args) {
		Carro meuCarro = new Carro();
		meuCarro.cor = "verde";
		meuCarro.modelo = "Fusca";
		meuCarro.velocidadeAtual = 0;
		Motor motor = new Motor();
		
		motor.potencia = 1000;
		motor.velocidadeMaxima = 500;
		meuCarro.motor = motor;
		
		meuCarro.liga();
		
		meuCarro.acelera(80);
		System.out.println(meuCarro.velocidadeAtual);
		meuCarro.acelera(500);
	}
}
