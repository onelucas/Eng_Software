public class Casa {
	String color;
	Porta porta1;
	Porta porta2;
	Porta porta3;

	public void pinta(String cor) {
		this.color = cor;
	}
	
	public int quantasPortasEstaoAbertas() {
		int i = (this.porta1.estaAberta()) ? 1 : 0;
		i += (this.porta2.estaAberta()) ? 1 : 0;
		i += (this.porta3.estaAberta()) ? 1 : 0;
		return i;
	}
}
