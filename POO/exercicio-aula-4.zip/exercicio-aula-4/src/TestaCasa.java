public class TestaCasa {

	public static void main(String[] args) {
		Casa c = new Casa();
		Porta p1 = new Porta();
		p1.color = "preto";
		Porta p2 = new Porta();
		p2.color = "amarelo";
		Porta p3 = new Porta();
		p3.color = "amarelo";
		
		p1.abre();
		c.porta1 = p1;
		c.porta2 = p2;
		c.porta3 = p3;
		c.pinta("Amarelo");
		System.out.println(c.quantasPortasEstaoAbertas());
	}
}
