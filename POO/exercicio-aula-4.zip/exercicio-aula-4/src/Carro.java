
public class Carro {

	String cor;
	String modelo;
	double velocidadeAtual;
	Motor motor;
	
	void liga() {	
		System.out.println("O carro esta ligado!");
	}

	void acelera(double quantidade) {
		double novaVelocidade = this.velocidadeAtual + quantidade;
		if (this.motor.validaAceleracao(novaVelocidade)) {
			this.velocidadeAtual += novaVelocidade;
		} else {
			System.out.println("Fundiu o motor");
		}
	}
}
